def hello(event, context):
    print(event)